package com.example.model;
import java.util.*;

public class BeerExpert {
	public ArrayList getBrands(String color) {
		ArrayList brands = new ArrayList();
		if(color.equals("amber")){
			brands.add("jack");
			brands.add("red");
		}
		else {
			brands.add("jail");
			brands.add("gout");
		}
		return(brands);
	}
}