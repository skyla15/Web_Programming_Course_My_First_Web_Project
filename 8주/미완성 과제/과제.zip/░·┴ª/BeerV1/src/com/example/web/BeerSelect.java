package com.example.web;

import com.example.model.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class BeerSelect extends HttpServlet {
	
	public void doPost(HttpServletRequest request, HttpServeletResponse response)throws IOException, servletException {
		
		String c = request.getParameter("color");
		BeerEexpert be = new BeerExpert();
		List Result = be.getBrands(c);

		request.setAttribute("styles", result);
		
			RequestDispatcher view =
				request.getRequestDispatcher("result.jsp");
		
			view.forward(request, response);
	}
}
